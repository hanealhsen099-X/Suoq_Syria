/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Home,
  Plus,
  User,
  Bell,
  X,
  ArrowRight,
  PlusCircle,
  Camera,
  Image as ImageIcon,
  MapPin,
  Trash2,
  MessageCircle,
  LogOut,
  LogIn,
  UserPlus,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Clock,
} from 'lucide-react';
import { supabase } from './lib/supabase';
import { uploadToCloudinary } from './lib/cloudinary';
import type { User as SupabaseUser } from '@supabase/supabase-js';

interface AdminNotification {
  id: string;
  title: string;
  message: string;
  created_at?: string;
  date?: string;
  is_read?: boolean;
}

interface ProductItem {
  id: string;
  title: string;
  category: string;
  sub_category: string;
  province: string;
  location: string;
  price?: string;
  whatsapp: string;
  image_url?: string;
  description?: string;
  user_id?: string;
  created_at: string;
}

// هيكلية الأقسام والأقسام الفرعية التابعة لكل قسم
interface CategoryDefinition {
  id: string;
  name: string;
  subCategories: string[];
}

const CATEGORIES_DATA: CategoryDefinition[] = [
  {
    id: 'real_estate',
    name: 'عقارات',
    subCategories: [
      'شقق للبيع',
      'شقق للإيجار',
      'أراضي ومزارع',
      'مكاتب ومحلات تجارية',
      'بيوت وفلل',
    ],
  },
  {
    id: 'electronics',
    name: 'إلكترونيات',
    subCategories: [
      'هواتف ذكية',
      'كمبيوتر ولابتوب',
      'شاشات وتلفزيونات',
      'أجهزة لوحية',
      'إكسسوارات وملحقات',
    ],
  },
  {
    id: 'solar_energy',
    name: 'الطاقة البديلة وأنظمة الطاقة',
    subCategories: [
      'ألواح الطاقة الشمسية',
      'البطاريات',
      'جيل ليثيوم',
      'المحولات',
      'المنظمات وملحقاتها',
    ],
  },
  {
    id: 'vehicles',
    name: 'السيارات والمركبات',
    subCategories: [
      'سيارات للبيع',
      'سيارات للإيجار',
      'دراجات نارية',
      'قطع غيار وإكسسوارات السيارات',
      'إطارات وبطاريات سيارات',
    ],
  },
  {
    id: 'home_furniture',
    name: 'المنزل والأثاث',
    subCategories: [
      'الأثاث المنزلي والمكتبي',
      'المفروشات',
      'أدوات المطبخ',
      'الأجهزة الكهربائية المنزلية',
      'برادات',
      'غسالات',
      'طباخات',
    ],
  },
  {
    id: 'fashion',
    name: 'الأزياء والموضة',
    subCategories: [
      'ملابس رجالية ونسائية وأطفال',
      'أحذية',
      'إكسسوارات',
      'ساعات وعطور',
    ],
  },
  {
    id: 'services',
    name: 'الخدمات والأعمال',
    subCategories: [
      'خدمات صيانة',
      'طاقة كهربائية',
      'كمبيوتر',
      'أجهزة منزلية',
    ],
  },
  {
    id: 'kids_toys',
    name: 'مستلزمات الأطفال والألعاب',
    subCategories: [
      'عربات أطفال',
      'ملابس أطفال',
      'ألعاب تعليمية وترفيهية',
    ],
  },
  {
    id: 'equipment_industry',
    name: 'المعدات والصناعة',
    subCategories: [
      'معدات',
      'ورشات',
      'أدوات حرفية ومهنية',
      'مواد أولية',
      'بضائع جملة',
    ],
  },
];

// قائمة محافظات سوريا الـ 14
const SYRIAN_PROVINCES = [
  'دمشق',
  'ريف دمشق',
  'حلب',
  'حمص',
  'حماة',
  'اللاذقية',
  'طرطوس',
  'إدلب',
  'درعا',
  'السويداء',
  'القنيطرة',
  'دير الزور',
  'الرقة',
  'الحسكة',
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'me'>('home');

  // القسم الرئيسي والفرعي النشط
  const [activeCategoryName, setActiveCategoryName] = useState<string>('عقارات');
  const [activeSubCategory, setActiveSubCategory] = useState<string>('الكل');

  // المستخدم والمصادقة مع Supabase
  const [currentUser, setCurrentUser] = useState<SupabaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  // حقول إنشاء الحساب الجديد الإضافية
  const [signupFullName, setSignupFullName] = useState('');
  const [signupFatherName, setSignupFatherName] = useState('');
  const [signupMotherName, setSignupMotherName] = useState('');
  const [signupBirthInfo, setSignupBirthInfo] = useState('');
  const [signupProvince, setSignupProvince] = useState('');
  const [signupAddress, setSignupAddress] = useState('');
  const [signupNationalId, setSignupNationalId] = useState('');

  // نظام التحقق من إنسان أو روبوت (Bot Protection / Turnstile)
  const [isCaptchaVerified, setIsCaptchaVerified] = useState(false);
  const [isCaptchaChecking, setIsCaptchaChecking] = useState(false);

  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // الإشعارات من Supabase
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  // قائمة المنتجات الحقيقية من Supabase
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);

  // حالة منبثقة زر الزائد
  const [showPlusMenu, setShowPlusMenu] = useState(false);

  // حالة واجهة النشر
  const [showCreateScreen, setShowCreateScreen] = useState(false);

  // الحقول المطلوبة لواجهة نشر المنتج
  const [productImageFile, setProductImageFile] = useState<File | null>(null);
  const [productImagePreview, setProductImagePreview] = useState<string | null>(null);
  const [productName, setProductName] = useState('');
  const [productCategory, setProductCategory] = useState<string>('عقارات');
  const [productSubCategory, setProductSubCategory] = useState<string>(''); // إلزامي
  const [selectedProvince, setSelectedProvince] = useState('');
  const [productAddress, setProductAddress] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productWhatsapp, setProductWhatsapp] = useState(''); // رقم واتساب إلزامي
  const [productDescription, setProductDescription] = useState('');

  // حالة الرفع والنشر
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStep, setPublishStep] = useState<string>('');
  const [publishError, setPublishError] = useState<string | null>(null);
  const [publishSuccess, setPublishSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // الاستماع للجلسة الحالية في Supabase
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setCurrentUser(session?.user ?? null);
      setAuthLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setCurrentUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // جلب المنتجات والإشعارات من Supabase
  const fetchProducts = async () => {
    try {
      setLoadingProducts(true);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        setProducts(data as ProductItem[]);
      }
    } catch {
      // التعامل الهادئ عند عدم وجود جدول حتى ينشئه المستخدم
    } finally {
      setLoadingProducts(false);
    }
  };

  const fetchNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        setNotifications(data as AdminNotification[]);
      }
    } catch {
      // هادئ
    }
  };

  useEffect(() => {
    fetchProducts();
    fetchNotifications();
  }, []);

  // تفعيل التحقق من إنسان (محاكاة Turnstile / Captcha)
  const handleVerifyCaptcha = () => {
    if (isCaptchaVerified || isCaptchaChecking) return;
    setIsCaptchaChecking(true);
    setTimeout(() => {
      setIsCaptchaChecking(false);
      setIsCaptchaVerified(true);
    }, 700);
  };

  // تسجيل الدخول بواسطة Google أو Facebook المتصل بسحابة Supabase
  const handleOAuthLogin = async (provider: 'google' | 'facebook') => {
    setAuthError(null);
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) {
        if (
          error.message?.toLowerCase().includes('not enabled') ||
          error.message?.toLowerCase().includes('unsupported provider')
        ) {
          throw new Error(
            `تسجيل الدخول عبر ${provider === 'google' ? 'Google' : 'Facebook'} يتطلب تفعيل المزود أولاً من لوحة تحكم Supabase الخاصة بك: Authentication > Providers > ${provider === 'google' ? 'Google' : 'Facebook'}.`
          );
        }
        throw error;
      }
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : `فشل تسجيل الدخول بواسطة ${provider}`;
      setAuthError(message);
    }
  };

  // معالجة تسجيل الدخول / إنشاء الحساب
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    // التحقق من نظام مكافحة الروبوت
    if (!isCaptchaVerified) {
      setAuthError('يرجى التحقق من أنك لست برنامج روبوت (الضغط على المربع)');
      return;
    }

    setAuthSubmitting(true);

    try {
      if (authMode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({
          email: authEmail,
          password: authPassword,
        });
        if (error) throw error;
      } else {
        // التحقق من الحقول الإلزامية الخاصة بإنشاء الحساب
        if (!signupFullName.trim()) throw new Error('يرجى إدخال الاسم الثلاثي');
        if (!signupFatherName.trim()) throw new Error('يرجى إدخال اسم الأب');
        if (!signupMotherName.trim()) throw new Error('يرجى إدخال اسم ونسبة الأم');
        if (!signupBirthInfo.trim()) throw new Error('يرجى إدخال محل وتاريخ الولادة');
        if (!signupProvince) throw new Error('يرجى اختيار المحافظة');
        if (!signupAddress.trim()) throw new Error('يرجى إدخال العنوان');
        if (!signupNationalId.trim()) throw new Error('يرجى إدخال الرقم الوطني');

        const { error, data } = await supabase.auth.signUp({
          email: authEmail,
          password: authPassword,
          options: {
            data: {
              full_name: signupFullName.trim(),
              father_name: signupFatherName.trim(),
              mother_name: signupMotherName.trim(),
              birth_place_date: signupBirthInfo.trim(),
              province: signupProvince,
              address: signupAddress.trim(),
              national_id: signupNationalId.trim(),
            },
          },
        });
        if (error) throw error;

        // محاولة حفظ البيانات في جدول profiles أيضاً
        if (data.user) {
          try {
            await supabase.from('profiles').upsert({
              id: data.user.id,
              full_name: signupFullName.trim(),
              father_name: signupFatherName.trim(),
              mother_name: signupMotherName.trim(),
              birth_place_date: signupBirthInfo.trim(),
              province: signupProvince,
              address: signupAddress.trim(),
              national_id: signupNationalId.trim(),
            });
          } catch {
            // هادئ
          }
        }

        // إشعار التحقق من البريد الإلكتروني كما طلب المستخدم
        setAuthSuccessMsg(
          'تم إنشاء الحساب بنجاح! تم إرسال رسالة تحقق إلى بريدك الإلكتروني، يرجى فتح البريد وتأكيد الحساب للمتابعة.'
        );
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'حدث خطأ في العملية';
      setAuthError(message);
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  // اختيار صورة المنتج
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProductImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProductImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setProductImageFile(null);
    setProductImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // معالجة ونشر الإعلان فعلياً إلى السحابة
  const handlePublishSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPublishError(null);

    // التحقق من الحقول الإلزامية
    if (!productName.trim()) {
      setPublishError('يرجى كتابة اسم المنتج');
      return;
    }
    if (!productCategory) {
      setPublishError('يرجى تحديد القسم الرئيسي');
      return;
    }
    if (!productSubCategory) {
      setPublishError('يرجى اختيار القسم الفرعي (إلزامي)');
      return;
    }
    if (!selectedProvince) {
      setPublishError('يرجى اختيار المحافظة');
      return;
    }
    if (!productAddress.trim()) {
      setPublishError('يرجى كتابة العنوان والمنطقة');
      return;
    }
    if (!productWhatsapp.trim()) {
      setPublishError('يرجى إدخال رقم الواتساب للتواصل (إلزامي)');
      return;
    }

    setIsPublishing(true);
    setPublishStep('جارٍ معالجة الصورة...');

    try {
      let finalImageUrl = '';

      // 1. رفع الصورة عبر Cloudinary إن وجدت
      if (productImageFile || productImagePreview) {
        setPublishStep('جارٍ ضغط ورفع الصورة...');
        finalImageUrl = await uploadToCloudinary(productImageFile || productImagePreview!);
      }

      // 2. حفظ الإعلان في قاعدة بيانات Supabase
      setPublishStep('جارٍ حفظ الإعلان في سحابة سوبابيس...');
      const newProductRecord = {
        title: productName.trim(),
        category: productCategory,
        sub_category: productSubCategory,
        province: selectedProvince,
        location: productAddress.trim(),
        price: productPrice.trim() || null,
        whatsapp: productWhatsapp.trim(),
        image_url: finalImageUrl || null,
        description: productDescription.trim() || null,
        user_id: currentUser?.id || null,
      };

      const { data, error } = await supabase
        .from('products')
        .insert([newProductRecord])
        .select();

      if (error) {
        throw error;
      }

      // إضافة الإعلان محلياً وتحديث القائمة
      if (data && data[0]) {
        setProducts((prev) => [data[0] as ProductItem, ...prev]);
      } else {
        fetchProducts();
      }

      setPublishSuccess(true);
      setTimeout(() => {
        setPublishSuccess(false);
        setIsPublishing(false);
        // تصفير الحقول
        setProductName('');
        setProductSubCategory('');
        setSelectedProvince('');
        setProductAddress('');
        setProductPrice('');
        setProductWhatsapp('');
        setProductDescription('');
        removeImage();
        setShowCreateScreen(false);
        setActiveTab('home');
        setActiveCategoryName(productCategory);
        setActiveSubCategory(productSubCategory);
      }, 1200);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'حدث خطأ أثناء نشر الإعلان';
      setPublishError(message);
      setIsPublishing(false);
    }
  };

  // تصفية المنتجات في الرئيسية
  const currentCategoryItems = products.filter((i) => {
    if (i.category !== activeCategoryName) return false;
    if (activeSubCategory !== 'الكل' && i.sub_category !== activeSubCategory) return false;
    return true;
  });

  // إعلانات المستخدم المسجل حالياً
  const myProducts = products.filter((i) => currentUser && i.user_id === currentUser.id);

  // حذف إعلان المستخدم
  const handleDeleteProduct = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الإعلان؟')) return;
    try {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (!error) {
        setProducts((prev) => prev.filter((p) => p.id !== id));
      }
    } catch {
      // هادئ
    }
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const handleSelectCategory = (catName: string) => {
    setActiveCategoryName(catName);
    setActiveSubCategory('الكل');
  };

  const currentCategoryData = CATEGORIES_DATA.find((c) => c.name === activeCategoryName);
  const activeCreateCategoryData = CATEGORIES_DATA.find((c) => c.name === productCategory);

  // ==========================================
  // واجهة نشر الإعلان
  // ==========================================
  if (showCreateScreen) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between select-none">
        {/* شريط أعلى واجهة النشر */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
          <div className="max-w-md mx-auto w-full flex items-center justify-between">
            <button
              type="button"
              disabled={isPublishing}
              onClick={() => setShowCreateScreen(false)}
              className="flex items-center gap-1.5 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer p-1"
            >
              <ArrowRight className="w-5 h-5" />
              <span>رجوع</span>
            </button>
            <h2 className="text-base font-bold text-slate-900">نشر إعلان جديد</h2>
            <div className="w-12"></div>
          </div>
        </header>

        {/* نموذج واجهة نشر المنتج */}
        <main className="flex-1 max-w-md mx-auto w-full px-4 py-5 overflow-y-auto">
          {publishSuccess ? (
            <div className="bg-white rounded-2xl p-8 border border-emerald-100 shadow-sm text-center flex flex-col items-center justify-center my-12">
              <CheckCircle2 className="w-16 h-16 text-emerald-500 mb-3 animate-bounce" />
              <h3 className="text-lg font-bold text-slate-900 mb-1">تم نشر الإعلان بنجاح في السحابة!</h3>
              <p className="text-xs text-slate-500">جاري توجيهك إلى صفحة الإعلانات...</p>
            </div>
          ) : (
            <form onSubmit={handlePublishSubmit} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
              
              {publishError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{publishError}</span>
                </div>
              )}

              {/* 1. إرفاق صورة للمنتج */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  1. صورة المنتج أو الإعلان
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageChange}
                  accept="image/*"
                  className="hidden"
                  id="product-image-upload"
                />

                {productImagePreview ? (
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50 aspect-video flex items-center justify-center group">
                    <img
                      src={productImagePreview}
                      alt="معاينة صورة المنتج"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 rounded-full bg-white text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                        title="تغيير الصورة"
                      >
                        <Camera className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={removeImage}
                        className="p-2 rounded-full bg-red-600 text-white hover:bg-red-700 transition-colors cursor-pointer"
                        title="حذف الصورة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-5 flex flex-col items-center justify-center gap-2 bg-slate-50/50 hover:bg-emerald-50/20 transition-all cursor-pointer text-slate-500 hover:text-emerald-700"
                  >
                    <div className="w-10 h-10 rounded-full bg-white shadow-xs flex items-center justify-center text-slate-400">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold">اضغط لإرفاق صورة المنتج</span>
                    <span className="text-[10px] text-slate-400">PNG, JPG (يتم ضغطها تلقائياً)</span>
                  </button>
                )}
              </div>

              {/* 2. اسم المنتج */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  2. اسم المنتج *
                </label>
                <input
                  type="text"
                  required
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="أدخل اسم المنتج أو الإعلان..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                />
              </div>

              {/* اختيار القسم الرئيسي */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  القسم الرئيسي *
                </label>
                <select
                  value={productCategory}
                  onChange={(e) => {
                    setProductCategory(e.target.value);
                    setProductSubCategory('');
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm cursor-pointer appearance-none text-slate-800"
                >
                  {CATEGORIES_DATA.map((cat) => (
                    <option key={cat.id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* القسم الفرعي (إلزامي كما طلبت) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  القسم الفرعي التابع لـ ({productCategory}) * (إلزامي)
                </label>
                <select
                  required
                  value={productSubCategory}
                  onChange={(e) => setProductSubCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm cursor-pointer appearance-none text-slate-800"
                >
                  <option value="">-- اختر القسم الفرعي المطلوب --</option>
                  {activeCreateCategoryData?.subCategories.map((sub) => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. المحافظة: يختار هو في أي محافظة من محافظات سوريا */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  3. المحافظة *
                </label>
                <div className="relative">
                  <select
                    required
                    value={selectedProvince}
                    onChange={(e) => setSelectedProvince(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm cursor-pointer appearance-none text-slate-800"
                  >
                    <option value="" disabled>
                      اختر محافظة من محافظات سوريا
                    </option>
                    {SYRIAN_PROVINCES.map((prov) => (
                      <option key={prov} value={prov}>
                        {prov}
                      </option>
                    ))}
                  </select>
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <MapPin className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* 4. العنوان والمنطقة: مثال دمشق - المزة... إلخ (بدون شارع الفيلات) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  4. العنوان والمنطقة *
                </label>
                <input
                  type="text"
                  required
                  value={productAddress}
                  onChange={(e) => setProductAddress(e.target.value)}
                  placeholder="مثال: دمشق - المزة... إلخ"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                />
              </div>

              {/* 5. رقم الواتساب للتواصل (إلزامي قبل النشر كما طلبت) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  5. رقم الواتساب للتواصل * (إلزامي)
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={productWhatsapp}
                    onChange={(e) => setProductWhatsapp(e.target.value)}
                    placeholder="مثال: 0912345678 أو 9639..."
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-right"
                  />
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-600">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* 6. السعر بالليرة السورية */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  6. السعر بالليرة السورية (اختياري)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={productPrice}
                    onChange={(e) => setProductPrice(e.target.value)}
                    placeholder="المبلغ الذي تريد..."
                    className="w-full pl-20 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                  />
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                    ليرة سورية
                  </span>
                </div>
              </div>

              {/* تفاصيل إضافية */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  تفاصيل إضافية عن المنتج (اختياري)
                </label>
                <textarea
                  rows={3}
                  value={productDescription}
                  onChange={(e) => setProductDescription(e.target.value)}
                  placeholder="أدخل أي مواصفات أو تفاصيل للمشتري..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm resize-none"
                />
              </div>

              {/* زر النشر الفعلي مع مؤشر التحميل */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isPublishing}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold rounded-xl text-sm transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 disabled:opacity-75 disabled:cursor-wait"
                >
                  {isPublishing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{publishStep || 'جارٍ النشر في السحابة...'}</span>
                    </>
                  ) : (
                    <span>نشر الإعلان الآن</span>
                  )}
                </button>
              </div>
            </form>
          )}
        </main>
      </div>
    );
  }

  // ==========================================
  // الواجهة الرئيسية
  // ==========================================
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between select-none">
      {/* أعلى الشاشة: اسم التطبيق وهو سوق سوريا، وفي أعلى اليسار أيقونة الإشعارات */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto w-full relative flex items-center justify-center">
          {/* اسم التطبيق في الوسط */}
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            سوق سوريا
          </h1>

          {/* في أعلى اليسار: أيقونة الإشعارات */}
          <div className="absolute left-0 flex items-center">
            <button
              type="button"
              onClick={() => setShowNotifications(true)}
              className="relative p-2 rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="الإشعارات"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* شريط الأقسام والمصنفات في الرئيسية تحت الهيدر مباشرة */}
      {activeTab === 'home' && (
        <div className="bg-white border-b border-slate-200 sticky top-[53px] z-20 shadow-2xs">
          <div className="max-w-md mx-auto">
            {/* 1. الشريط الرئيسي للأقسام */}
            <div className="px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth">
              {CATEGORIES_DATA.map((cat) => {
                const isSelected = activeCategoryName === cat.name;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => handleSelectCategory(cat.name)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all duration-150 cursor-pointer whitespace-nowrap shrink-0 ${
                      isSelected
                        ? 'bg-emerald-600 text-white shadow-xs scale-[1.02]'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>

            {/* 2. الأقسام الفرعية التابعة للقسم المختار */}
            {currentCategoryData && currentCategoryData.subCategories.length > 0 && (
              <div className="px-4 pb-2 pt-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth bg-slate-50/70 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setActiveSubCategory('الكل')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    activeSubCategory === 'الكل'
                      ? 'bg-slate-800 text-white shadow-2xs'
                      : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  الكل
                </button>
                {currentCategoryData.subCategories.map((sub) => {
                  const isSubSelected = activeSubCategory === sub;
                  return (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => setActiveSubCategory(sub)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        isSubSelected
                          ? 'bg-slate-800 text-white shadow-2xs'
                          : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100 hover:text-slate-700'
                      }`}
                    >
                      {sub}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* المحتوى الرئيسي */}
      <main className="flex-1 max-w-md mx-auto w-full px-4 py-4 flex flex-col">
        {activeTab === 'home' ? (
          <div className="flex-1 flex flex-col">
            {loadingProducts ? (
              <div className="flex-1 flex items-center justify-center py-20 text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
              </div>
            ) : currentCategoryItems.length === 0 ? (
              <div className="flex-1 flex items-center justify-center py-20 text-center">
                <p className="text-sm font-medium text-slate-400">
                  لا توجد منشورات حالياً في هذا القسم
                </p>
              </div>
            ) : (
              <div className="w-full space-y-3">
                {currentCategoryItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs text-right flex flex-col gap-2.5 hover:shadow-xs transition-shadow"
                  >
                    {item.image_url && (
                      <div className="w-full aspect-video rounded-xl overflow-hidden bg-slate-100 border border-slate-100">
                        <img
                          src={item.image_url}
                          alt={item.title}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      </div>
                    )}
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-bold text-sm text-slate-900 leading-snug">
                        {item.title}
                      </h4>
                      {item.price && (
                        <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-lg whitespace-nowrap">
                          {item.price} ل.س
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100">
                      <span className="flex items-center gap-1 text-[11px]">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{item.province} - {item.location}</span>
                      </span>

                      {/* زر التواصل عبر الواتساب */}
                      {item.whatsapp && (
                        <a
                          href={`https://wa.me/${item.whatsapp.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs shadow-xs transition-all"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>تواصل واتساب</span>
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* ==========================================
             قسم "أنا": مصادقة حقيقية مع سحابة Supabase
             ========================================== */
          <div className="flex-1 flex flex-col py-4">
            {authLoading ? (
              <div className="flex-1 flex items-center justify-center py-20">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
              </div>
            ) : currentUser ? (
              /* عندما يكون المستخدم مسجّل دخول فعلياً */
              <div className="space-y-4">
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs text-center flex flex-col items-center">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2 font-bold text-xl">
                    {currentUser.user_metadata?.full_name?.charAt(0) || currentUser.email?.charAt(0).toUpperCase()}
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    {currentUser.user_metadata?.full_name || currentUser.email}
                  </h3>
                  <span className="text-[11px] text-slate-400 mt-0.5">
                    {currentUser.email}
                  </span>

                  {currentUser.user_metadata?.national_id && (
                    <div className="mt-3 pt-3 border-t border-slate-100 w-full grid grid-cols-2 gap-2 text-right text-xs">
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] block">الرقم الوطني</span>
                        <span className="font-bold text-slate-700">{currentUser.user_metadata.national_id}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] block">المحافظة</span>
                        <span className="font-bold text-slate-700">{currentUser.user_metadata.province || 'غير محدد'}</span>
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="mt-4 flex items-center gap-1.5 text-xs text-red-600 hover:text-red-700 font-bold px-3 py-1.5 rounded-lg bg-red-50 border border-red-100 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>تسجيل الخروج</span>
                  </button>
                </div>

                {/* إعلانات المستخدم */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
                  <h4 className="font-bold text-sm text-slate-900 mb-3 pb-2 border-b border-slate-100">
                    إعلاناتي المنشورة ({myProducts.length})
                  </h4>
                  {myProducts.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-6">
                      لم تقم بنشر أي إعلانات حتى الآن
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {myProducts.map((p) => (
                        <div
                          key={p.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-150"
                        >
                          <div>
                            <span className="font-bold text-xs text-slate-800 block">
                              {p.title}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {p.category} - {p.sub_category}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                            title="حذف الإعلان"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* نموذج تسجيل الدخول / إنشاء الحساب مع Supabase Auth */
              <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4 my-auto">
                <div className="flex items-center justify-center gap-2 p-1 bg-slate-100 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('login');
                      setAuthError(null);
                      setAuthSuccessMsg(null);
                    }}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      authMode === 'login'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    تسجيل الدخول
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('signup');
                      setAuthError(null);
                      setAuthSuccessMsg(null);
                    }}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      authMode === 'signup'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    حساب جديد
                  </button>
                </div>

                <div className="text-center">
                  <h3 className="font-bold text-slate-900 text-sm">
                    {authMode === 'login' ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب جديد في سوق سوريا'}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {authMode === 'login'
                      ? 'اختر طريقة الدخول المفضلة لديك'
                      : 'أدخل معلوماتك الشخصية لإنشاء حساب موثق'}
                  </p>
                </div>

                {/* أزرار الدخول بواسطة Google و Facebook في وضع تسجيل الدخول */}
                {authMode === 'login' && (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => handleOAuthLogin('google')}
                      className="w-full py-2.5 px-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>متابعة باستخدام Google</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleOAuthLogin('facebook')}
                      className="w-full py-2.5 px-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                    >
                      <svg className="w-4 h-4 text-[#1877F2]" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                      <span>متابعة باستخدام Facebook</span>
                    </button>

                    <div className="flex items-center gap-2 my-2">
                      <div className="flex-1 h-px bg-slate-200"></div>
                      <span className="text-[11px] text-slate-400">أو عبر البريد الإلكتروني</span>
                      <div className="flex-1 h-px bg-slate-200"></div>
                    </div>
                  </div>
                )}

                {authError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{authError}</span>
                  </div>
                )}

                {authSuccessMsg && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-start gap-2.5 text-right">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{authSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleAuth} className="space-y-3">
                  {/* الحقول الإضافية المطلوبة عند إنشاء حساب جديد */}
                  {authMode === 'signup' && (
                    <div className="space-y-3 pt-1">
                      {/* 1. الاسم الثلاثي */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          الاسم الثلاثي *
                        </label>
                        <input
                          type="text"
                          required
                          value={signupFullName}
                          onChange={(e) => setSignupFullName(e.target.value)}
                          placeholder="مثال: محمد أحمد العلي"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                        />
                      </div>

                      {/* 2. اسم الأب & 3. اسم ونسبة الأم */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            اسم الأب *
                          </label>
                          <input
                            type="text"
                            required
                            value={signupFatherName}
                            onChange={(e) => setSignupFatherName(e.target.value)}
                            placeholder="اسم الأب"
                            className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            اسم ونسبة الأم *
                          </label>
                          <input
                            type="text"
                            required
                            value={signupMotherName}
                            onChange={(e) => setSignupMotherName(e.target.value)}
                            placeholder="اسم ونسبة الأم"
                            className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                          />
                        </div>
                      </div>

                      {/* 4. محل وتاريخ الولادة */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          محل وتاريخ الولادة *
                        </label>
                        <input
                          type="text"
                          required
                          value={signupBirthInfo}
                          onChange={(e) => setSignupBirthInfo(e.target.value)}
                          placeholder="مثال: دمشق 15/05/1995"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                        />
                      </div>

                      {/* 5. المحافظة */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          المحافظة *
                        </label>
                        <select
                          required
                          value={signupProvince}
                          onChange={(e) => setSignupProvince(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs cursor-pointer appearance-none text-slate-800"
                        >
                          <option value="" disabled>
                            اختر المحافظة
                          </option>
                          {SYRIAN_PROVINCES.map((prov) => (
                            <option key={prov} value={prov}>
                              {prov}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* 6. العنوان */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          العنوان بالتفصيل *
                        </label>
                        <input
                          type="text"
                          required
                          value={signupAddress}
                          onChange={(e) => setSignupAddress(e.target.value)}
                          placeholder="مثال: دمشق - المزة"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                        />
                      </div>

                      {/* 7. الرقم الوطني */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          الرقم الوطني * (11 رقم)
                        </label>
                        <input
                          type="text"
                          required
                          dir="ltr"
                          value={signupNationalId}
                          onChange={(e) => setSignupNationalId(e.target.value)}
                          placeholder="01010123456"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-right"
                        />
                      </div>
                    </div>
                  )}

                  {/* البريد الإلكتروني وكلمة المرور */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      البريد الإلكتروني *
                    </label>
                    <input
                      type="email"
                      required
                      dir="ltr"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      كلمة المرور *
                    </label>
                    <input
                      type="password"
                      required
                      dir="ltr"
                      minLength={6}
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-right"
                    />
                  </div>

                  {/* نظام التحقق من إنسان أو روبوت (Turnstile / Captcha) */}
                  <div className="pt-1">
                    <div
                      onClick={handleVerifyCaptcha}
                      className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-100/70 transition-colors flex items-center justify-between cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-6 h-6 rounded-md border flex items-center justify-center transition-all ${
                            isCaptchaVerified
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'bg-white border-slate-300'
                          }`}
                        >
                          {isCaptchaChecking ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
                          ) : isCaptchaVerified ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : null}
                        </div>
                        <span className="text-xs font-semibold text-slate-700">
                          أنا لست برنامج روبوت
                        </span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-slate-400 font-bold">Cloudflare</span>
                        <span className="text-[9px] text-slate-400">Turnstile الحماية</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs cursor-pointer flex items-center justify-center gap-2 disabled:opacity-75 mt-2"
                  >
                    {authSubmitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : authMode === 'login' ? (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>تسجيل الدخول</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>إنشاء الحساب</span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}
          </div>
        )}
      </main>

      {/* أسفل الشاشة:
          - أسفل اليمين: قسم أو أيقونة الرئيسية
          - في الوسط: أيقونة زائد (+)
          - في اليسار: قسم أنا
      */}
      <nav className="sticky bottom-0 z-30 bg-white border-t border-slate-200 px-6 py-2 shadow-sm">
        <div className="max-w-md mx-auto w-full grid grid-cols-3 items-center">
          {/* في اليمين: الرئيسية */}
          <div className="flex justify-start">
            <button
              type="button"
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'home'
                  ? 'text-emerald-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <Home className="w-6 h-6" />
              <span className="text-xs">الرئيسية</span>
            </button>
          </div>

          {/* في الوسط: أيقونة زائد (تفتح المنبثقة) */}
          <div className="flex justify-center relative">
            <button
              type="button"
              onClick={() => setShowPlusMenu(true)}
              className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-md hover:bg-emerald-700 active:scale-95 transition-all cursor-pointer"
              aria-label="إضافة"
            >
              <Plus className="w-6 h-6 stroke-[2.5]" />
            </button>
          </div>

          {/* في اليسار: أنا */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setActiveTab('me')}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'me'
                  ? 'text-emerald-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <User className="w-6 h-6" />
              <span className="text-xs">أنا</span>
            </button>
          </div>
        </div>
      </nav>

      {/* منبثقة زر الزائد */}
      {showPlusMenu && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-end sm:items-center justify-center p-4"
          onClick={() => setShowPlusMenu(false)}
        >
          <div
            className="bg-white rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden border border-slate-100 flex flex-col p-4 animate-in fade-in slide-in-from-bottom-4 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">خيارات الإضافة</h3>
              <button
                type="button"
                onClick={() => setShowPlusMenu(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowPlusMenu(false);
                setShowCreateScreen(true);
              }}
              className="flex items-center justify-between w-full p-3.5 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-800 hover:bg-emerald-100/70 transition-all cursor-pointer font-bold text-sm"
            >
              <div className="flex items-center gap-2.5">
                <PlusCircle className="w-5 h-5 text-emerald-600" />
                <span>نشر إعلان جديد</span>
              </div>
              <ArrowRight className="w-4 h-4 rotate-180 text-emerald-600" />
            </button>
          </div>
        </div>
      )}

      {/* نافذة الإشعارات المتصلة بـ Supabase */}
      {showNotifications && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowNotifications(false)}
        >
          <div
            className="bg-white rounded-2xl w-full max-w-sm shadow-xl overflow-hidden border border-slate-100 flex flex-col max-h-[80vh] animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-100 bg-slate-50/70">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-emerald-600" />
                <h2 className="font-bold text-slate-800 text-base">إشعارات الإدارة</h2>
              </div>
              <button
                type="button"
                onClick={() => setShowNotifications(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
                aria-label="إغلاق"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3">
              {notifications.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  لا توجد إشعارات حالياً
                </div>
              ) : (
                notifications.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-right flex flex-col gap-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900">
                        {item.title}
                      </span>
                      {item.created_at && (
                        <span className="text-[10px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(item.created_at).toLocaleDateString('ar-SY')}</span>
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.message}
                    </p>
                  </div>
                ))
              )}
            </div>

            <div className="p-3 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => setShowNotifications(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
