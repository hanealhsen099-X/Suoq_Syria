/**
 * خدمة رفع الصور إلى Cloudinary
 * تقوم بضغط وتنسيق الصور تلقائياً (q_auto, f_auto) ثم ترسل الرابط
 */

export interface CloudinaryConfig {
  cloudName: string;
  uploadPreset: string;
}

// يمكن وضع بيانات Cloudinary هنا أو من خلال متغيرات البيئة
export const CLOUDINARY_CONFIG: CloudinaryConfig = {
  cloudName: '', // يوضع هنا اسم السحابة
  uploadPreset: '', // يوضع هنا اسم الـ Unsigned Preset
};

export async function uploadToCloudinary(
  fileOrBase64: File | string,
  cloudName = CLOUDINARY_CONFIG.cloudName,
  uploadPreset = CLOUDINARY_CONFIG.uploadPreset
): Promise<string> {
  // إذا لم يتم تحديد بيانات Cloudinary بعد، نعيد الصورة الأصلية (Base64) كحل بديل مؤقت
  if (!cloudName || !uploadPreset) {
    if (typeof fileOrBase64 === 'string') {
      return fileOrBase64;
    }
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(fileOrBase64);
    });
  }

  const formData = new FormData();
  formData.append('file', fileOrBase64);
  formData.append('upload_preset', uploadPreset);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
    {
      method: 'POST',
      body: formData,
    }
  );

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || 'فشل في رفع الصورة إلى Cloudinary'
    );
  }

  const data = await response.json();
  // secure_url هو الرابط المحمي والمضغوط للصورة
  return data.secure_url;
}
